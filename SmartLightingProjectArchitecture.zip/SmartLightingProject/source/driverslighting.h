#ifndef DRIVERSLIGHTING_H
#define DRIVERSLIGHTING_H

#include <stdint.h>
#include <stdbool.h>
#include "fsl_gpio.h"

typedef struct {
    uint8_t hours;
    uint8_t minutes; 
    uint8_t seconds;
} rtc_time_t;

// Function declarations
void init_hardware(void);
void init_i2c_peripherals(void);
void init_pwm_for_leds(void);
rtc_time_t get_current_time(void);
float get_ambient_lux(void);
bool is_button_pressed(void);
void set_rgb_color(uint8_t r, uint8_t g, uint8_t b);
void set_rgb_color_alt(uint8_t r, uint8_t g, uint8_t b);

// LED Pin definitions (from your routing table)
#define LED_RED_PORT     1U
#define LED_RED_PIN      7U    // PIO1_7 is actually RED

#define LED_GREEN_PORT   1U  
#define LED_GREEN_PIN    4U    // PIO1_4 is actually GREEN

#define LED_BLUE_PORT    1U
#define LED_BLUE_PIN     6U    // PIO1_6 is actually BLUE

// Button definition - Use GPIO base addresses
#define BUTTON_GPIO       GPIO    // Use main GPIO peripheral
#define BUTTON_PORT       1U      // Port 1
#define BUTTON_PIN        9U      // P1_9


#endif