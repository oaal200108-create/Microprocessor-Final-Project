#include "driverslighting.h"
#include "fsl_gpio.h"
#include "fsl_common.h"

// Initialize hardware
void init_hardware(void)
{
    // Initialize GPIO clocks
    CLOCK_EnableClock(kCLOCK_Gpio0);
    CLOCK_EnableClock(kCLOCK_Gpio1);
    
    // Configure LED pins as outputs
    gpio_pin_config_t led_config = {
        kGPIO_DigitalOutput,
        0,
    };
    
    GPIO_PinInit(GPIO, LED_BLUE_PORT, LED_BLUE_PIN, &led_config);
    GPIO_PinInit(GPIO, LED_RED_PORT, LED_RED_PIN, &led_config); 
    GPIO_PinInit(GPIO, LED_GREEN_PORT, LED_GREEN_PIN, &led_config);
    
    // Initialize button as input
    gpio_pin_config_t button_config = {
        kGPIO_DigitalInput,
        0,
    };
    GPIO_PinInit(BUTTON_GPIO, BUTTON_PORT, BUTTON_PIN, &button_config);
}

// Set RGB LED color using direct GPIO control
void set_rgb_color(uint8_t r, uint8_t g, uint8_t b)
{
    // INVERTED LOGIC for active-low LEDs
    GPIO_PinWrite(GPIO, LED_RED_PORT, LED_RED_PIN, (r > 127) ? 0U : 1U);
    GPIO_PinWrite(GPIO, LED_GREEN_PORT, LED_GREEN_PIN, (g > 127) ? 0U : 1U);
    GPIO_PinWrite(GPIO, LED_BLUE_PORT, LED_BLUE_PIN, (b > 127) ? 0U : 1U);
}
// Alternative implementation (same as above)
void set_rgb_color_alt(uint8_t r, uint8_t g, uint8_t b)
{
    set_rgb_color(r, g, b);  // Just call the main function
}

// Placeholder implementations
void init_i2c_peripherals(void) { /* TODO */ }
void init_pwm_for_leds(void) { /* TODO */ }

rtc_time_t get_current_time(void)
{
    rtc_time_t t = {12, 0, 0};
    return t;
}

float get_ambient_lux(void) { return 300.0f; }

bool is_button_pressed(void) 
{ 
    return (GPIO_PinRead(BUTTON_GPIO, BUTTON_PORT, BUTTON_PIN) == 0U);
}