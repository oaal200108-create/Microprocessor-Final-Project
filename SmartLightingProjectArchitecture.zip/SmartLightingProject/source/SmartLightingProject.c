#include "driverslighting.h"
#include <stdint.h>

int main(void)
{
    // Initialize hardware
    init_hardware();

    // TEST: Basic LED Color Cycle
    while(1) {
        set_rgb_color(255, 0, 0);   // RED
        for (volatile int i = 0; i < 1000000; i++);

        set_rgb_color(0, 255, 0);   // GREEN
        for (volatile int i = 0; i < 1000000; i++);

        set_rgb_color(0, 0, 255);   // BLUE
        for (volatile int i = 0; i < 1000000; i++);

        set_rgb_color(255, 255, 255); // WHITE
        for (volatile int i = 0; i < 1000000; i++);

        set_rgb_color(0, 0, 0);     // OFF
        for (volatile int i = 0; i < 1000000; i++);
    }

    return 0;
}
