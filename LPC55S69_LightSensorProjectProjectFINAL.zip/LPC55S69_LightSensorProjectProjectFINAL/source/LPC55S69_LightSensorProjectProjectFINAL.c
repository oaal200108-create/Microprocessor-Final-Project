#define SDK_DEBUGCONSOLE 1

#include <stdio.h>
#include <stdint.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
#include "Driver_I2C.h"

extern ARM_DRIVER_I2C     Driver_I2C4;
ARM_DRIVER_I2C           *I2C4drv = &Driver_I2C4;

/* VEML7700 I2C Address */
#define LIGHT_SENSOR_ADDR  0x10

/* VEML7700 Registers */
#define VEML7700_ALS_CONF         0x00
#define VEML7700_ALS_DATA         0x04

/* LED Threshold (lux) */
#define LUX_THRESHOLD  50.0f

/* Simple delay */
static void delay_ms(uint32_t ms)
{
    for (volatile uint32_t i = 0; i < ms * 3000; i++)
        __NOP();
}

/* Write 16-bit configuration to VEML7700 */
static void VEML7700_WriteRegister(uint8_t reg, uint16_t value)
{
    uint8_t data[3];
    data[0] = reg;
    data[1] = value & 0xFF;
    data[2] = (value >> 8) & 0xFF;
    I2C4drv->MasterTransmit(LIGHT_SENSOR_ADDR, data, 3, false);
    delay_ms(10);
}

/* Read raw data from VEML7700 */
uint16_t LightSensor_ReadRaw(void)
{
    uint8_t reg = VEML7700_ALS_DATA;
    uint8_t data[2] = {0};

    /* Tell the sensor which register we want */
    I2C4drv->MasterTransmit(LIGHT_SENSOR_ADDR, &reg, 1, true);

    /* Read 2 bytes of ALS data */
    I2C4drv->MasterReceive(LIGHT_SENSOR_ADDR, data, 2, false);

    return (data[1] << 8) | data[0];
}

/* Convert raw readings to lux (simplified scale) */
float ConvertToLux(uint16_t raw)
{
    return raw * 0.0576f;
}

int main(void)
{
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
    BOARD_InitDebugConsole();

    PRINTF("Starting VEML7700 Light Sensor Program...\r\n");

    /* Initialize I2C */
    I2C4drv->Initialize(NULL);
    I2C4drv->PowerControl(ARM_POWER_FULL);
    I2C4drv->Control(ARM_I2C_BUS_SPEED, ARM_I2C_BUS_SPEED_STANDARD);

    /* Configure VEML7700 (gain + integration time defaults) */
    VEML7700_WriteRegister(VEML7700_ALS_CONF, 0x0000);

    while (1)
    {
        uint16_t raw_value = LightSensor_ReadRaw();
        float lux = ConvertToLux(raw_value);

        PRINTF("Raw: %u   Lux: %.2f\r\n", raw_value, lux);

        /* LED control (turn ON if dark, OFF if bright) */
        if (lux < LUX_THRESHOLD)
        {
            LED_RED_ON();
        }
        else
        {
            LED_RED_OFF();
        }

        delay_ms(500);
    }
}

